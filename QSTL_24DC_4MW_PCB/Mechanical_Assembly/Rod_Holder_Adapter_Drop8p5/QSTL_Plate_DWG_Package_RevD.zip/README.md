# Split mounting plate drawings - Rev D

The drawing layout was revised against the native Enclosure3 DWG/IPN workflow.
Scope: central plate with integral boss, left support, right support and their eight-screw assembly.

## Drawings

- Manufacturing_DWG/QSTL_Split_Mount_RevD_QSTL-CP01.dwg: central plate overall and hole-pattern dimensions.
- Manufacturing_DWG/QSTL_Split_Mount_RevD_QSTL-CP02.dwg: central plate thread and countersink sections.
- Manufacturing_DWG/QSTL_Split_Mount_RevD_QSTL-LS01.dwg and RS01.dwg: separate support drawings.
- Manufacturing_DWG/QSTL_Split_Mount_RevD_QSTL-AS01.dwg: native presentation-linked exploded assembly, eight fastening axes, assembled boss-side view and fastening section C-C.
- Manufacturing_DWG/QSTL_Split_Mount_RevD_Inventor.dwg: combined five-sheet master.
- Manufacturing_DWG/QSTL_Split_Mount_RevD.pdf: print-layout companion.

All six DWGs are native Inventor drawings, with editable model-associated views and dimensions on ISO A3 landscape sheets. Native borders and title blocks are used. The manually typed BOM and assembly-sequence blocks were removed. No general NOTES block or cylinder/device/frame installation drawing is included.

The IPN contains two real presentation tweaks and one associative snapshot. Eight supplemental vector axis trails identify individual screw-to-hole alignment on AS01. The IAM/IPN and source IPT files are included; retain the directory structure when extracting the package. The source part STEP files are also included.

Material: oxygen-free copper. Surface treatment: none.

Device lip reliefs: two 72 mm long grooves beside the boss, 0.5 mm deep with R0.5 end corners. The measured device lip is 3.0398406169 mm thick; groove width is 3.3398406169 mm (lip + 0.3 mm). The groove allowance extends outward to retain the original boss contact faces, device placement and thread axes. CP01 locates the grooves; CP02 section B-B dimensions width and depth.

Internal threaded holes retain native Inventor ISO Metric profile M3x0.5, class 6H, right-hand: ten in the central boss and four in each support. The eight assembly screws are unmodified Inventor 2027 Content Center DIN 7991 M3x10 members, with native M3x0.5-6g external thread features and hexagonal drives. Their 6 mm heads include a 0.2 mm rim; the 6.6 mm x 90-degree countersinks seat the head fronts 0.1 mm below the deck. Nominal engagement is 6.1 mm, with 0.4 mm remaining bore depth. Content Center cosmetic thread cylinders overlap the pilot-bore representation only within the intended threaded engagement; head and clearance-region interference is checked separately.

Validation: all six DWGs reopened in Inventor; five A3 sheets, 46 attached model dimensions without value overrides, linked IPN assembly view, unchanged source CAD hashes during drawing generation, and rendered-page layout inspection. Independent STEP validation checks groove volume, floor height, width, corner radii, retained boss/threads, device alignment and rod contact area.

## Final support flange revision - 2026-09-24

Both outer rod-contact flanges are 1.60 mm thick with full-thickness C1.6 x 45-degree outer bevels. The central deck remains 4 mm thick. The rod mating plane, full rod contact footprints, 8.5 mm mounting drop, boss and device placement are unchanged.

The four rod fastener holes in each support remain plain diameter 3.4 mm through holes; no support-flange thread features are present. The user cancelled flange threading after confirming that the reference rods already specify M3 through threads. The eight rod screws are now unmodified Content Center ISO 7380-1 M3x8 button-head members. They retain their insertion direction through the support into the rod and bearing planes at global Z=-1.6 mm. The original rods remain unchanged. With the provisional 6 mm rod depth, the screw tips project 0.4 mm beyond the rods. No washers are used.

With the ISO 7380-1 button heads, the C1.6 bevel leaves 70.70% of the actual flat under-head bearing area supported (10.845 of 15.339 mm2 per rod screw). The previous 67.11% result applies to the superseded ISO 4762 rod heads. Geometry checks do not constitute preload or structural qualification. Existing reference-part/sleeve intersections and tiny device under-head fillet intersections remain recorded in the full assembly report.

The PCB pocket-floor centre plus 0.300 mm toward the cavity opening is at X=25.500, Z=3.000 mm, matching the cylinder axis. Calculated nominal radial residual is below 0.001 mm; the unrounded CAD value is recorded in geometry_verification.json. Cylinder_top_1p6mm.png is a literal native axial view; Cylinder_centre_1p6mm.png is a STEP-derived section exposing the pocket reference point hidden behind the crossbars in that view.

Validation: independent saved support IPT copies, one healthy solid per part, native C1.6 chamfer, four unchanged deck-joining M3x0.5-6H threads per support, and no added flange threads. STEP checks confirm the requested cut volume, 20,000 matching point classifications per part, rod contact and screw seating. All six Rev D DWGs reopen with 46 attached dimensions. Previous revision drawing/ZIP files outside this package are superseded and must not be paired with current models.


## Button-head rod hardware - 2026-09-24

Eight rod screws are actual Inventor 2027 Content Center ISO 7380-1 M3x8 members: head diameter 5.7 mm, head height 1.65 mm, 2 mm hex drive, M3x0.5-6g external thread. The two device screws and eight DIN 7991 plate screws remain unchanged. The copied library member retains its original SHA-256 and Content Center identity. No washers are present.

The native assembly was saved and reopened. Only the eight rod occurrence file references changed; every occurrence transform and all three fabricated IPT/STEP pairs are unchanged. STEP solid validity and assembly/component volume agreement were checked using adaptive integration for the curved heads. See rod_button_head_native_audit.json and rod_button_head_verification.json in the model directory.

Per rod screw, the sleeve overlap falls from approximately 3.398 to 0.576 mm3, but is not eliminated. The supplied R0.3 under-head fillet also intersects the unchamfered 3.4 mm flange-hole mouth by approximately 0.00492 mm3. This is an unresolved geometric seating issue, not cosmetic thread overlap. Hole geometry and supplied screws were not modified to conceal it. Original rod-corner/support/sleeve clashes and device fillet intersections remain.

Cylinder_top_round_heads.png shows the native axial view; Rod_button_head_assembly.png shows the mounting screws with the sleeve hidden for inspection. Fabricated geometry, the plate-only IAM/IPN and all six Rev D DWGs are byte-for-byte unchanged by this hardware-only update. Rod installation is outside the plate drawing scope; source_cad_hashes.json remains the historical drawing-generation record, including its then-current full-installation IAM hash. The rod change does not invalidate the associated plate views.
